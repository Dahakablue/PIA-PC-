


def escribir(img,savefile,datos):
  archivo = open(savefile +"/datos.txt", 'a+')
  var = savefile + "/datos.txt"
  archivo.write("\n" + img + "\n" + datos)
  archivo.close()





  
  

  

  





